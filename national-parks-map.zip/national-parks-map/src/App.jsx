import React, { useEffect, useMemo, useState } from 'react';
import { geoAlbersUsa, geoPath } from 'd3-geo';
import { feature } from 'topojson-client';
import statesTopology from 'us-atlas/states-10m.json';
import parks from '../np.json';

const WIDTH = 980;
const HEIGHT = 610;
const STATE_IDS = new Set([
  '01',
  '02',
  '04',
  '05',
  '06',
  '08',
  '09',
  '10',
  '12',
  '13',
  '15',
  '16',
  '17',
  '18',
  '19',
  '20',
  '21',
  '22',
  '23',
  '24',
  '25',
  '26',
  '27',
  '28',
  '29',
  '30',
  '31',
  '32',
  '33',
  '34',
  '35',
  '36',
  '37',
  '38',
  '39',
  '40',
  '41',
  '42',
  '44',
  '45',
  '46',
  '47',
  '48',
  '49',
  '50',
  '51',
  '53',
  '54',
  '55',
  '56',
]);

const STATE_NAME_BY_ID = {
  '01': 'Alabama',
  '02': 'Alaska',
  '04': 'Arizona',
  '05': 'Arkansas',
  '06': 'California',
  '08': 'Colorado',
  '09': 'Connecticut',
  10: 'Delaware',
  12: 'Florida',
  13: 'Georgia',
  15: 'Hawaii',
  16: 'Idaho',
  17: 'Illinois',
  18: 'Indiana',
  19: 'Iowa',
  20: 'Kansas',
  21: 'Kentucky',
  22: 'Louisiana',
  23: 'Maine',
  24: 'Maryland',
  25: 'Massachusetts',
  26: 'Michigan',
  27: 'Minnesota',
  28: 'Mississippi',
  29: 'Missouri',
  30: 'Montana',
  31: 'Nebraska',
  32: 'Nevada',
  33: 'New Hampshire',
  34: 'New Jersey',
  35: 'New Mexico',
  36: 'New York',
  37: 'North Carolina',
  38: 'North Dakota',
  39: 'Ohio',
  40: 'Oklahoma',
  41: 'Oregon',
  42: 'Pennsylvania',
  44: 'Rhode Island',
  45: 'South Carolina',
  46: 'South Dakota',
  47: 'Tennessee',
  48: 'Texas',
  49: 'Utah',
  50: 'Vermont',
  51: 'Virginia',
  53: 'Washington',
  54: 'West Virginia',
  55: 'Wisconsin',
  56: 'Wyoming',
};

const CALLOUT_LABELS = {
  '09': [876, 211],
  10: [873, 283],
  24: [869, 306],
  25: [878, 161],
  33: [860, 105],
  34: [875, 258],
  44: [893, 187],
  50: [835, 84],
};

function normalizeId(id) {
  return String(id).padStart(2, '0');
}

function parseFormattedNumber(value) {
  return Number(String(value).replace(/,/g, ''));
}

function formatNumber(value) {
  return new Intl.NumberFormat('en-US').format(value);
}

function getParkStateNames(park) {
  return park.states.map((state) => state.title).join(', ');
}

function ParkMarker({ park, x, y, onShow, onHide, onSelect }) {
  const stateNames = getParkStateNames(park);
  const openDetails = () => onSelect(park);

  return (
    <g
      className="park-marker"
      transform={`translate(${x} ${y})`}
      tabIndex="0"
      role="button"
      aria-label={`${park.title} National Park, ${stateNames}`}
      onMouseEnter={() => onShow({ park, x, y })}
      onMouseLeave={onHide}
      onFocus={() => onShow({ park, x, y })}
      onBlur={onHide}
      onClick={openDetails}
      onKeyDown={(event) => {
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault();
          openDetails();
        }
      }}
    >
      <circle r="5.8" className="park-marker__halo" />
      <circle r="3.2" className="park-marker__core" />
    </g>
  );
}

function App() {
  const [activePark, setActivePark] = useState(null);
  const [selectedPark, setSelectedPark] = useState(null);
  const [parkFilter, setParkFilter] = useState('all');
  const showWorldHeritageOnly = parkFilter === 'world-heritage';
  const map = useMemo(() => {
    const allStates = feature(
      statesTopology,
      statesTopology.objects.states,
    ).features;
    const states = allStates.filter((state) => STATE_IDS.has(normalizeId(state.id)));
    const collection = { type: 'FeatureCollection', features: states };
    const projection = geoAlbersUsa().fitExtent(
      [
        [28, 24],
        [952, 580],
      ],
      collection,
    );
    const path = geoPath(projection);

    const parkPoints = parks.map((park) => {
      const projected = projection([
        park.coordinates.longitude,
        park.coordinates.latitude,
      ]);

      return {
        park,
        projected,
      };
    });

    return {
      states,
      path,
      parkPoints: parkPoints.filter((item) => item.projected),
      outsideProjection: parkPoints.filter((item) => !item.projected),
    };
  }, []);

  const rankedData = useMemo(() => {
    const rankedParks = parks.map((park) => ({
      ...park,
      visitorsValue: parseFormattedNumber(park.visitors),
      acresValue: parseFormattedNumber(park.area.acres),
    }));

    const popular = [...rankedParks]
      .sort((first, second) => second.visitorsValue - first.visitorsValue)
      .slice(0, 10);
    const biggest = [...rankedParks]
      .sort((first, second) => second.acresValue - first.acresValue)
      .slice(0, 10);

    return {
      popular,
      biggest,
    };
  }, []);

  const visibleParkIds = useMemo(() => {
    if (parkFilter === 'world-heritage') {
      return new Set(
        parks.filter((park) => park.world_heritage_site).map((park) => park.id),
      );
    }

    if (parkFilter === 'top-biggest') {
      return new Set(rankedData.biggest.map((park) => park.id));
    }

    if (parkFilter === 'top-popular') {
      return new Set(rankedData.popular.map((park) => park.id));
    }

    return null;
  }, [parkFilter, rankedData]);

  const visibleParkPoints = useMemo(
    () =>
      map.parkPoints.filter(
        ({ park }) => !visibleParkIds || visibleParkIds.has(park.id),
      ),
    [map, visibleParkIds],
  );

  const visibleOutsideProjection = useMemo(
    () =>
      map.outsideProjection.filter(
        ({ park }) => !visibleParkIds || visibleParkIds.has(park.id),
      ),
    [map, visibleParkIds],
  );

  useEffect(() => {
    if (selectedPark && visibleParkIds && !visibleParkIds.has(selectedPark.id)) {
      setSelectedPark(null);
    }

    if (activePark && visibleParkIds && !visibleParkIds.has(activePark.park.id)) {
      setActivePark(null);
    }
  }, [activePark, selectedPark, visibleParkIds]);

  const calloutSource = useMemo(
    () =>
      new Map(
        map.states.map((state) => [
          normalizeId(state.id),
          map.path.centroid(state),
        ]),
      ),
    [map],
  );

  const chartData = useMemo(() => {
    const rankedParks = parks
      .filter((park) => !showWorldHeritageOnly || park.world_heritage_site)
      .map((park) => ({
        ...park,
        visitorsValue: parseFormattedNumber(park.visitors),
        acresValue: parseFormattedNumber(park.area.acres),
      }));

    const popular = [...rankedParks]
      .sort((first, second) => second.visitorsValue - first.visitorsValue)
      .slice(0, 10);
    const biggest = [...rankedParks]
      .sort((first, second) => second.acresValue - first.acresValue)
      .slice(0, 10);

    return {
      popular,
      biggest,
      maxVisitors: popular[0]?.visitorsValue ?? 0,
      maxAcres: biggest[0]?.acresValue ?? 0,
    };
  }, [showWorldHeritageOnly]);

  return (
    <main className="app-shell">
      <header className="page-header">
        <h1>United States National Parks Map</h1>
      </header>

      <section className="map-stage" aria-label="United States map with national park locations">
        <div className="map-canvas">
          <div className="map-filter" role="group" aria-label="Map park filter">
            <label htmlFor="park-filter" className="map-filter__label">
              Show
            </label>
            <select
              id="park-filter"
              className="map-filter__select"
              value={parkFilter}
              onChange={(event) => {
                setParkFilter(event.target.value);
                setActivePark(null);
              }}
            >
              <option value="all">All parks</option>
              <option value="world-heritage">World Heritage Parks</option>
              <option value="top-biggest">Top 10 Biggest Parks</option>
              <option value="top-popular">Top 10 Most Popular Parks</option>
            </select>
          </div>

          <svg
            className="usa-map"
            viewBox={`0 0 ${WIDTH} ${HEIGHT}`}
            role="img"
            aria-labelledby="map-title map-description"
          >
            <title id="map-title">United States National Parks Map</title>
            <desc id="map-description">
              A map of the fifty United States with state labels and national park
              points plotted by latitude and longitude.
            </desc>

            <g className="states">
              {map.states.map((state) => {
                const id = normalizeId(state.id);
                const name = STATE_NAME_BY_ID[id];

                return (
                  <path key={id} d={map.path(state)} className="state-shape">
                    <title>{name}</title>
                  </path>
                );
              })}
            </g>

            <g className="state-labels" aria-hidden="true">
              {map.states.map((state) => {
                const id = normalizeId(state.id);
                const name = STATE_NAME_BY_ID[id];
                const callout = CALLOUT_LABELS[id];

                if (callout) {
                  return null;
                }

                const [x, y] = map.path.centroid(state);
                const words = name.split(' ');

                return (
                  <text key={id} x={x} y={y} className="state-label">
                    {words.map((word, index) => (
                      <tspan
                        key={word}
                        x={x}
                        dy={index === 0 ? 0 : 10}
                      >
                        {word}
                      </tspan>
                    ))}
                  </text>
                );
              })}
            </g>

            <g className="state-callouts" aria-hidden="true">
              {Object.entries(CALLOUT_LABELS).map(([id, labelPoint]) => {
                const source = calloutSource.get(id);
                const name = STATE_NAME_BY_ID[id];

                if (!source) {
                  return null;
                }

                return (
                  <g key={id} className="state-callout">
                    <line
                      x1={source[0]}
                      y1={source[1]}
                      x2={labelPoint[0] - 8}
                      y2={labelPoint[1] - 3}
                    />
                    <text x={labelPoint[0]} y={labelPoint[1]}>
                      {name}
                    </text>
                  </g>
                );
              })}
            </g>

            <g className="park-points">
              {visibleParkPoints.map(({ park, projected }) => (
                <ParkMarker
                  key={park.id}
                  park={park}
                  x={projected[0]}
                  y={projected[1]}
                  onShow={setActivePark}
                  onHide={() => setActivePark(null)}
                  onSelect={setSelectedPark}
                />
              ))}
            </g>
          </svg>

          {activePark && (
            <div
              className="park-tooltip"
              style={{
                left: `${(activePark.x / WIDTH) * 100}%`,
                top: `${(activePark.y / HEIGHT) * 100}%`,
              }}
            >
              <div className="park-tooltip__title">{activePark.park.title}</div>
              {activePark.park.world_heritage_site && (
                <div className="park-tooltip__badge">World Heritage Site</div>
              )}
              <dl className="park-tooltip__facts">
                <div>
                  <dt>Total visitors</dt>
                  <dd>{activePark.park.visitors}</dd>
                </div>
                <div>
                  <dt>Total area</dt>
                  <dd>{activePark.park.area.acres} acres</dd>
                </div>
              </dl>
            </div>
          )}
        </div>

        {visibleOutsideProjection.length > 0 && (
          <div className="territory-parks" aria-label="National parks outside the fifty state map projection">
            <span>Territory parks</span>
            {visibleOutsideProjection.map(({ park }) => (
              <a key={park.id} href={park.nps_link} target="_blank" rel="noreferrer">
                {park.title}
              </a>
            ))}
          </div>
        )}
      </section>

      <section className="chart-grid" aria-label="National park rankings">
        <article className="rank-chart">
          <h2>
            Top 10 Most Popular National Parks
            {showWorldHeritageOnly ? ' (World Heritage)' : ''}
          </h2>
          <ol>
            {chartData.popular.map((park) => (
              <li key={park.id}>
                <div className="rank-chart__row">
                  <span className="rank-chart__name">{park.title}</span>
                  <span className="rank-chart__state">({getParkStateNames(park)})</span>
                  <span className="rank-chart__value">
                    {formatNumber(park.visitorsValue)} visitors
                  </span>
                </div>
                <div className="rank-chart__track" aria-hidden="true">
                  <div
                    className="rank-chart__bar rank-chart__bar--visitors"
                    style={{ width: `${(park.visitorsValue / chartData.maxVisitors) * 100}%` }}
                  />
                </div>
              </li>
            ))}
          </ol>
        </article>

        <article className="rank-chart">
          <h2>
            Top 10 Biggest National Parks
            {showWorldHeritageOnly ? ' (World Heritage)' : ''}
          </h2>
          <ol>
            {chartData.biggest.map((park) => (
              <li key={park.id}>
                <div className="rank-chart__row">
                  <span className="rank-chart__name">{park.title}</span>
                  <span className="rank-chart__state">({getParkStateNames(park)})</span>
                  <span className="rank-chart__value">
                    {formatNumber(park.acresValue)} acres
                  </span>
                </div>
                <div className="rank-chart__track" aria-hidden="true">
                  <div
                    className="rank-chart__bar rank-chart__bar--acres"
                    style={{ width: `${(park.acresValue / chartData.maxAcres) * 100}%` }}
                  />
                </div>
              </li>
            ))}
          </ol>
        </article>
      </section>

      {selectedPark && (
        <aside className="park-pane" aria-label={`${selectedPark.title} details`}>
          <button
            className="park-pane__close"
            type="button"
            aria-label="Close park details"
            onClick={() => setSelectedPark(null)}
          >
            X
          </button>

          <div className="park-pane__image-wrap">
            <img
              className="park-pane__image"
              src={selectedPark.image.url}
              alt={`${selectedPark.title} National Park`}
              onError={(event) => {
                event.currentTarget.hidden = true;
                event.currentTarget.nextElementSibling.hidden = false;
              }}
            />
            {/* <div className="park-pane__image-fallback" hidden>
              Image unavailable
            </div> */}
          </div>

          <div className="park-pane__content">
            <h2>{selectedPark.title}</h2>
            {selectedPark.world_heritage_site && (
              <div className="park-pane__badge">World Heritage Site</div>
            )}
            <p>{selectedPark.description}</p>

            <dl className="park-pane__facts">
              <div>
                <dt>Total visitors</dt>
                <dd>{selectedPark.visitors}</dd>
              </div>
              <div>
                <dt>Total area</dt>
                <dd>{selectedPark.area.acres} acres</dd>
              </div>
            </dl>

            <a
              className="park-pane__link"
              href={selectedPark.nps_link}
              target="_blank"
              rel="noreferrer"
            >
              Know more
            </a>
          </div>
        </aside>
      )}
    </main>
  );
}

export default App;
