import { mkdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';

const INPUT_FILE = 'np.json';
const OUTPUT_FILE = 'src/data/np-popular-places.json';
const API_BASE = 'https://developer.nps.gov/api/v1/places';
const API_KEY = process.env.NPS_API_KEY || 'DEMO_KEY';
const PLACES_PER_PARK = Number(process.env.PLACES_PER_PARK || 5);
const REQUEST_DELAY_MS = Number(process.env.NPS_REQUEST_DELAY_MS || 160);

const EXCLUDED_TITLE_PATTERNS = [
  /\bearthcache\b/i,
  /\bgeocache\b/i,
  /\bstop\s+(one|two|three|four|five|six|seven|eight|nine|ten|\d+)\b/i,
  /\bwayside\b/i,
  /\bpassport\b/i,
];

function parkCodeFromNpsLink(npsLink) {
  const match = npsLink.match(/nps\.gov\/([^/]+)\//i);
  return match?.[1] ?? null;
}

function numberOrNull(value) {
  if (value === null || value === undefined || value === '') {
    return null;
  }

  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function coordinatesFromLatLong(value) {
  if (!value) {
    return null;
  }

  const latitude = value.match(/lat(?:itude)?:\s*(-?\d+(?:\.\d+)?)/i);
  const longitude = value.match(/(?:long|lng|longitude):\s*(-?\d+(?:\.\d+)?)/i);

  if (!latitude || !longitude) {
    return null;
  }

  return {
    latitude: Number(latitude[1]),
    longitude: Number(longitude[1]),
  };
}

function decimalFromDms(direction, degrees, minutes = 0, seconds = 0) {
  const absolute =
    Number(degrees) + Number(minutes) / 60 + Number(seconds || 0) / 3600;
  return /[SW]/i.test(direction) ? -absolute : absolute;
}

function coordinatesFromText(text) {
  if (!text) {
    return null;
  }

  const normalized = text
    .replace(/&nbsp;/gi, ' ')
    .replace(/<[^>]*>/g, ' ')
    .replace(/[′’]/g, "'")
    .replace(/[″”]/g, '"')
    .replace(/\s+/g, ' ');

  const degreeMinute = normalized.match(
    /([NS])\s*(\d{1,3})\s*[°º]\s*(\d{1,2}(?:\.\d+)?)\s*['']?.*?([EW])\s*(\d{1,3})\s*[°º]\s*(\d{1,2}(?:\.\d+)?)\s*['']?/i,
  );

  if (degreeMinute) {
    return {
      latitude: decimalFromDms(degreeMinute[1], degreeMinute[2], degreeMinute[3]),
      longitude: decimalFromDms(degreeMinute[4], degreeMinute[5], degreeMinute[6]),
    };
  }

  const degreeMinuteSecond = normalized.match(
    /([NS])\s*(\d{1,3})\s*[°º]\s*(\d{1,2})\s*['']\s*(\d{1,2}(?:\.\d+)?)\s*["]?.*?([EW])\s*(\d{1,3})\s*[°º]\s*(\d{1,2})\s*['']\s*(\d{1,2}(?:\.\d+)?)\s*["]?/i,
  );

  if (degreeMinuteSecond) {
    return {
      latitude: decimalFromDms(
        degreeMinuteSecond[1],
        degreeMinuteSecond[2],
        degreeMinuteSecond[3],
        degreeMinuteSecond[4],
      ),
      longitude: decimalFromDms(
        degreeMinuteSecond[5],
        degreeMinuteSecond[6],
        degreeMinuteSecond[7],
        degreeMinuteSecond[8],
      ),
    };
  }

  return null;
}

function coordinatesForPlace(place) {
  const direct = {
    latitude: numberOrNull(place.latitude),
    longitude: numberOrNull(place.longitude),
  };

  if (direct.latitude !== null && direct.longitude !== null) {
    return direct;
  }

  return coordinatesFromLatLong(place.latLong) || coordinatesFromText(place.bodyText);
}

function placeScore(place) {
  const title = place.title || '';
  const tags = Array.isArray(place.tags) ? place.tags.join(' ') : '';
  const quickFacts = Array.isArray(place.quickFacts)
    ? place.quickFacts.map((fact) => `${fact.name} ${fact.value}`).join(' ')
    : '';
  const haystack = `${title} ${tags} ${quickFacts}`;

  let score = Number(place.relevanceScore || 0);

  if (EXCLUDED_TITLE_PATTERNS.some((pattern) => pattern.test(haystack))) {
    score -= 15;
  }

  if (/\bvisitor center\b/i.test(haystack)) score += 4;
  if (/\boverlook\b|\bviewpoint\b|\bscenic\b/i.test(haystack)) score += 3;
  if (/\btrail\b|\bfalls?\b|\blake\b|\bmountain\b|\bcanyon\b|\bbeach\b/i.test(haystack)) {
    score += 2;
  }
  if (place.isOpenToPublic === '1') score += 1;
  if (place.images?.length) score += 0.5;

  return score;
}

function toPopularPlace(place) {
  const coordinates = coordinatesForPlace(place);

  return {
    title: place.title,
    description: place.listingDescription || '',
    latitude: Number(coordinates.latitude.toFixed(6)),
    longitude: Number(coordinates.longitude.toFixed(6)),
    url: place.url,
    source: 'National Park Service places API',
  };
}

function sleep(ms) {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}

async function fetchPlaces(parkCode) {
  const url = new URL(API_BASE);
  url.searchParams.set('parkCode', parkCode);
  url.searchParams.set('limit', '100');
  url.searchParams.set('api_key', API_KEY);

  const response = await fetch(url);

  if (!response.ok) {
    throw new Error(`${response.status} ${response.statusText}`);
  }

  const payload = await response.json();
  return Array.isArray(payload.data) ? payload.data : [];
}

async function main() {
  const parks = JSON.parse(await readFile(INPUT_FILE, 'utf8'));
  let existingById = new Map();

  try {
    const existing = JSON.parse(await readFile(OUTPUT_FILE, 'utf8'));
    existingById = new Map(existing.map((park) => [park.id, park]));
  } catch {
    existingById = new Map();
  }

  const enriched = [];
  const failures = [];

  for (const park of parks) {
    const existingPark = existingById.get(park.id);
    if (existingPark?.popular_places?.length >= PLACES_PER_PARK) {
      enriched.push(existingPark);
      console.log(`${park.title}: ${existingPark.popular_places.length} places (cached)`);
      continue;
    }

    const parkCode = parkCodeFromNpsLink(park.nps_link);

    if (!parkCode) {
      failures.push({ park: park.title, reason: 'Could not derive park code' });
      enriched.push({ ...park, popular_places: [] });
      continue;
    }

    try {
      const places = await fetchPlaces(parkCode);
      const popularPlaces = places
        .filter((place) => coordinatesForPlace(place))
        .sort((first, second) => placeScore(second) - placeScore(first))
        .slice(0, PLACES_PER_PARK)
        .map(toPopularPlace);

      enriched.push({
        ...park,
        nps_park_code: parkCode,
        popular_places: popularPlaces,
      });

      console.log(`${park.title}: ${popularPlaces.length} places`);
    } catch (error) {
      failures.push({ park: park.title, parkCode, reason: error.message });
      enriched.push({
        ...park,
        nps_park_code: parkCode,
        popular_places: [],
      });
      console.warn(`${park.title}: ${error.message}`);
    }

    await sleep(REQUEST_DELAY_MS);
  }

  await mkdir(path.dirname(OUTPUT_FILE), { recursive: true });
  await writeFile(`${OUTPUT_FILE}`, `${JSON.stringify(enriched, null, 2)}\n`);
  await writeFile(
    'src/data/np-popular-places-failures.json',
    `${JSON.stringify(failures, null, 2)}\n`,
  );

  console.log(`Wrote ${OUTPUT_FILE}`);
  console.log(`Failures: ${failures.length}`);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
